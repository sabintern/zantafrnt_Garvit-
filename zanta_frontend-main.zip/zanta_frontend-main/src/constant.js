export const CompanyName = "Zanta";
export const CompanyNumber = "999999999";
export const CurrentYear = new Date().getFullYear();
export const showSocialLogin = false;
export const showHeaderAtLoginPage = false;
